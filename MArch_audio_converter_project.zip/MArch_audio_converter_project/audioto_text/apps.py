from django.apps import AppConfig


class AudiotoTextConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "audioto_text"
