from django.shortcuts import render, get_object_or_404
from .models import AudioFile
from pydub import AudioSegment
import os
from django.conf import settings

def dashboard(request):
    audio_files = AudioFile.objects.all()
    return render(request, 'dashboard.html', {'audio_files': audio_files})

def show_text(request, audio_file_id):
    audio_file = get_object_or_404(AudioFile, pk=audio_file_id)
    return render(request, 'show_text.html', {'audio_file': audio_file})


# from django.shortcuts import render
# import speech_recognition as sr
# from .models import AudioFile

def audio_to_text(request):
    if request.method == 'POST' and request.FILES['audio_file']:
        audio_file = request.FILES['audio_file']
        
        # Initialize recognizer
        recognizer = sr.Recognizer()
        
        # Recognize speech from audio file
        with sr.AudioFile(audio_file) as source:
            audio_data = recognizer.record(source)
        
        try:
            # Convert audio to text
            text = recognizer.recognize_google(audio_data)
            
            # Save the text to the database
            audio_file_obj = AudioFile.objects.create(audio=audio_file, text=text)
            
            return render(request, 'result.html', {'text': text, 'audio_file': audio_file_obj})
        except sr.UnknownValueError:
            return render(request, 'result.html', {'text': 'Sorry, could not understand audio.'})
        except sr.RequestError as e:
            return render(request, 'result.html', {'text': 'Error: {0}'.format(e)})
    
    return render(request, 'index.html')
