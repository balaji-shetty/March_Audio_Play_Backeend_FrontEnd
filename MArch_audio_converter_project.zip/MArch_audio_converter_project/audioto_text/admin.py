from django.contrib import admin
from django.utils.html import format_html
from .models import AudioFile

class AudioFileAdmin(admin.ModelAdmin):
    list_display = ('id', 'audio_player', 'text', 'created_at')

    def audio_player(self, obj):
        if obj.audio:
            return format_html('<audio controls src="{}"></audio>', obj.audio.url)
        else:
            return "No audio file"
    audio_player.short_description = 'Audio'

admin.site.register(AudioFile, AudioFileAdmin)
