from django.urls import path
from .views import audio_to_text, dashboard, show_text

urlpatterns = [
    path('', audio_to_text, name='audio_to_text'),
    path('dashboard/', dashboard, name='dashboard'),
    path('audio/<int:audio_file_id>/text/', show_text, name='show_text'),
]
